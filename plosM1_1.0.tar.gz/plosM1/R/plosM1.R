## function that transforms each of the (possibly constrained) model parameters to the real line
## params: combination of tranformed form of 11 vector parameters of total length 57
n2w = function(muMD,sgMD,muDT,sgDT,muPD,sgPD,rho,...) {
	c( log(c(muMD,sgMD,muDT,sgDT,muPD,sgPD)),
		atanh(rho), ... )
}

## inverse transformation back to the natural parameter space
w2n = function(params,N) 
{
	V1 = c('muMD','sgMD','muDT','sgDT','muPD','sgPD' ,'rho')
	F1 = c( rep('exp',6), 'tanh' )
	len = N # number of states: N
	L1 = seq(1,length.out=length(V1), by=len); L2 = (len-1) + L1
	L = mapply( FUN = function(a,b) {seq(a,b)}, L1, L2 )
	for (i in 1:length(V1))
		assign(V1[i], do.call( F1[i], list(params[L[,i]]) ))

	# Free parameters alpha: alpha1,alpha2,alpha3,...
	V2 = paste0('alpha',1:N) # alpha1 is 8th list of L: it's number 7 (c++ starts from 0) in TransMat function in cpp file; if no correlation, change 7 to 6 in cpp file
	len = N-1 # length of alpha... (alpha1,alpha2,alpha3,alpha4)
	L1 = seq(L2[length(L2)]+1,length.out=length(V2),by=len); 
	if (len > 1) {
		L2 = (len-1) + L1
		L = mapply( FUN = function(a,b) {seq(a,b)}, L1, L2 )
		for (i in 1:length(V2))	
			assign(V2[i], params[L[,i]] )
	} else {
		for (i in 1:length(V2))	
			assign(V2[i], params[L1[i]])
	}
		
		
	if (N==4)	idx = c(12,13,14, 21,23,24, 31,32,34, 41,42,43)
	if (N==3)	idx = c(12,13,21,23,31,32)
	if (N==2)	idx = c(12,21)
	V3 = c(paste0('theta',idx), paste0('delta',idx))
	len = 3 # degree of natural spline + diurnal spline: 3
	L1 = seq(L2[length(L2)]+1,length.out=length(V3),by=len); L2 = (len-1) + L1
	L = mapply( FUN = function(a,b) {seq(a,b)}, L1, L2 )	
	for (i in 1:length(V3))	
		assign(V3[i], params[L[,i]] )

	V = c(V1,V2,V3); mget(V)
}

## function that computes minus the log likelihood of the model described 
logLE = function(params,data,N, ... #,M,S,S_d
					)
{
	# compute natural parameters
	listParams = w2n(params,N)
	# print(listParams)
	# print(dim(M)); print(sum(M))
	
	# array of time-varying transition probabilities
	tp_matrix =	TransMat( NROW(data), N, listParams,... #, M,S,S_d
						)
	
	# # mllk = logLE_cpp_log(data=data, 
	mllk = logLE_cpp(data=data, 
					muMD=listParams$muMD, sgMD=listParams$sgMD,
					muDT=listParams$muDT, sgDT=listParams$sgDT,
					muPD=listParams$muPD, sgPD=listParams$sgPD, rho=listParams$rho,
					vecC=tp_matrix,dimC=dim(tp_matrix),N=N)
    return(mllk)
}

## function that runs the numerical maximization 
## of the above likelihood function and returns the results
mle = function(data, params,N, M,S,S_d,
								print,optFunc,iter=1000,hess=FALSE) 
{	
    # minimize negative log-likelihood with nlm
	if (optFunc==1) {
		mod = nlm(logLE,params,data=data,N=N, M=M,S=S,S_d=S_d,
				print.level=print,iterlim=iter,hessian=hess)
		# convert MLEs back to natural scale
		listParams = w2n(mod$estimate,N)
		c(listParams, list(argmax=mod$estimate, mllk=mod$minimum,
												H=mod$hessian, iteration=mod$iterations) )
	} else if (optFunc==2) {
		mod = optim(params,logLE,data=data,N=N, M=M,S=S,S_d=S_d,
								method = "BFGS",hessian=hess,
								control=list(maxit=iter, trace=(print*3) ) )
		# convert MLEs back to natural scale
		listParams = w2n(mod$par,N)
		c(listParams, list(argmax=mod$par, mllk=mod$value,
												H=mod$hessian, iteration=-mod$counts) )
	}
}

viterbi = function(data,m,L,...)
{
	T = nrow(data)
	MaxDepth = data[["MaxDepth"]]-19.5
	Duration = data[["Duration"]]
	PostDive = data[["PostDiveDur"]]
	allProbs = matrix(0,nrow=T,ncol=m)
	rho = L$rho
	for (t in 1:T) {
		x1 = MaxDepth[t]; x2 = Duration[t]; x3 = PostDive[t]
		for (i in 1:m) {
			y0 = 2*pi*sqrt(1-rho[i]*rho[i])*x1*x2
			a = (log(x1)-L$muMD[i])/L$sgMD[i]
			b = (log(x2)-L$muDT[i])/L$sgDT[i]
			y = y0*L$sgMD[i]*L$sgDT[i]*exp((a*a+b*b-2*rho[i]*a*b)/(2*(1-rho[i]*rho[i])))
			allProbs[t,i] = 1/y*dlnorm(x3,L$muPD[i],L$sgPD[i])
		}
	}
	# cat(T,m,sep=',')
	# transition probability matrix
	tp_matrix = TransMat(T,m, L,...)

  # compute most probably global state sequence
	zeta  = matrix(NA,T,m)
	# delta = rep(0,m); delta[1] = 1
	delta = rep(1/m,m)
	# delta = log(delta)
	zeta[1,] = delta*allProbs[1,]
	# Logarithm of Formula (5.9)
	# zeta[t,j]:= zeta_{t,j} (t=2,...,T; j = 1,...,m)
	for(t in 2:T) {
		foo = apply(zeta[t-1,]*(tp_matrix[,,t-1]),2,max)*allProbs[t,]
		zeta[t,] = foo/sum(foo)
		if (!all(is.finite(zeta[t,]))) {
			cat('\n',t,':', zeta[t-1,],'\n')
			print((tp_matrix[,,t-1]))
			print(zeta[t-1,]*(tp_matrix[,,t-1]))
			cat('\n\n')
		}
	}
	# stSeq: sequence of maximized states i_1,...,i_T
	stSeq = rep(NA,T)
	# which.max() := argmax()
	# cat(T,zeta[T,],'\n\n')
	stSeq[T] = which.max(zeta[T,]) # (5.10)
	for(t in (T-1):1) { # (5.11)
		# print(log(tp_matrix[,stSeq[t+1],t])+zeta[t,])
		stSeq[t] = which.max(tp_matrix[,stSeq[t+1],t]*zeta[t,])
  }
  return(stSeq)
}


#' Log forward probabilities
#' @param data Data 
#' @param mod Fitted model as output by mle
logAlpha = function(data,m,L,...)
{
	T = nrow(data)
	lalpha = matrix(NA,T,m)
	# matrix of state-dependent probabilities
	probs = matrix(1,nrow=T,ncol=m)	
	MaxDepth = data[["MaxDepth"]]-19.5
  Duration = data[["Duration"]]
	PostDive = data[["PostDiveDur"]]
	probs = matrix(1,nrow=T,ncol=m)
	rho = L$rho
	for (t in 1:T) {
		x1 = MaxDepth[t]; x2 = Duration[t]; x3 = PostDive[t]
		for (i in 1:m) {
			y0 = 2*pi*sqrt(1-rho[i]*rho[i])*x1*x2
			a = (log(x1)-L$muMD[i])/L$sgMD[i]
			b = (log(x2)-L$muDT[i])/L$sgDT[i]
			y = y0*L$sgMD[i]*L$sgDT[i]*exp((a*a+b*b-2*rho[i]*a*b)/(2*(1-rho[i]*rho[i])))
			probs[t,i] = 1/y*dlnorm(x3,L$muPD[i],L$sgPD[i])
		}
	}
	
	# transition probability matrix
	tp_matrix = TransMat(T,N=m,L,...)
	# delta = rep(0,m); delta[1] = 1
	lscale = 0; delta = rep(1/m,m)
	foo = delta*probs[1,]
	lalpha[1,] = log(foo)+lscale
	for(t in 2:T) {
		foo = foo%*%tp_matrix[,,t]*probs[t,]
		lscale = lscale+log(sum(foo))
		foo = foo/sum(foo)
		lalpha[t,] = log(foo)+lscale
	}
	return(lalpha)
}


pseudoRes = function(data,m,L,...)
{
	T = nrow(data)
	# forward log-probabilities
	la = logAlpha(data,m,L,...)
	MaxDepth = data[["MaxDepth"]]-19.5
	Duration = data[["Duration"]]
	PostDive = data[["PostDiveDur"]]
	stSeqMD = rep(NA,T); stSeqDT = rep(NA,T); stSeqPD = rep(NA,T)
	probsMD = matrix(NA,nrow=T,ncol=m)
	probsDT = matrix(NA,nrow=T,ncol=m)
	probsPD = matrix(NA,nrow=T,ncol=m)

	for (i in 1:m) {
		probsMD[,i] = plnorm(MaxDepth,meanlog=L$muMD[i],sdlog=L$sgMD[i])
		probsDT[,i] = plnorm(Duration,meanlog=L$muDT[i],sdlog=L$sgDT[i])
		probsPD[,i] = plnorm(PostDive,meanlog=L$muPD[i],sdlog=L$sgPD[i])
	}
	# transition probability matrix
	tp_matrix = TransMat(T,N=m,L,...)
	
	# delta = rep(0,m); delta[1] = 1
	delta = rep(1/m,m)
	stSeqMD[1] = qnorm(t(delta)%*%probsMD[1,])
	stSeqDT[1] = qnorm(t(delta)%*%probsDT[1,])
	stSeqPD[1] = qnorm(t(delta)%*%probsPD[1,])
	for(t in 2:T) {		
		a = exp(la[t-1,]-max(la[t-1,]))
		stSeqMD[t] = qnorm(t(a)%*%(tp_matrix[,,t]/sum(a))%*%probsMD[t,])
		stSeqDT[t] = qnorm(t(a)%*%(tp_matrix[,,t]/sum(a))%*%probsDT[t,])
		stSeqPD[t] = qnorm(t(a)%*%(tp_matrix[,,t]/sum(a))%*%probsPD[t,])
	}
	
	list(MaxDepth=stSeqMD,Duration=stSeqDT,PostDiveDur=stSeqPD)
}
