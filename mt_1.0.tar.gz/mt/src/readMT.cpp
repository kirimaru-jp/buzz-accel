
/*
 * datafile.h -- header format for single-channel digitized data files
 * in "MT" format (see Appendix D of Burgess, W.C., Lightning-induced
 * coupling of the radiation belts to geomagnetically conjugate
 * ionospheric regions, Ph.D. thesis, Stanford University, Stanford,
 * California, 1993).
 *
 * The MT header format consists of a master 512-byte header followed
 * by an arbitrary number of supplemental 512-byte headers.  Typically
 * there are no supplemental 512-byte headers, only the one master header,
 * but software to read MT format should be able to skip over any
 * supplemental headers declared in the master header.  The supplemental
 * headers are application-dependent; they might simply contain text
 * to explain the data in greater detail.
 *
 * For portability and ease of inspection, the header is made up entirely
 * of ASCII bytes.  For ease of reading with scanf, all multi-character
 * strings must be null-terminated.  All numbers, including floating-point
 * numbers, must be written as null terminated strings.  Floating-point
 * numbers may include decimal points and e+xx or e-xx exponential
 * notation as necessary.
 *
 * Please stick to the basic 128-char ASCII character set in all
 * fields.  However, if you need a greek letter "mu" in the
 * "calunits" field, a lower-case letter "u" may be interpreted by some
 * readers as a "mu" provided it comes before certain key characters or
 * character strings (e.g. "uV" "uPa" "uA" etc.).  Recognition of the
 * "u" as a "mu" is up to the reader software and is not required.
 *
 * If the bytes reserved for a field are incompletely filled by
 * characters or digits, the rest of the field is to be filled
 * with nulls ('\0').
 *
 * There are some single-character fields.  These are not read as
 * strings, but rather as single characters, and thus do not have
 * null-termination.
 *
 * The "DATA\0\0\0\0" identifier in the beginning is a "magic string"
 * that identifies the file as MT format.  Reader software must always
 * verify that a data file begins with these eight characters.
*/

#ifndef _DATAFILE_H_
#define _DATAFILE_H_

/*
 * This is how many characters, INCLUDING null terminator,
 * calibration value strings can be.
*/
#define MAX_CALSTRING_CHARS 15

/*
 * Possible values for the typemark field.
*/
#define AMPLITUDE   'A'
#define PHASE       'P'
#define REFERENCE   'R'
#define SPECIAL     'S' /* special or unknown */
#define PEAKDETECT  'D' /* from peak detector */
#define DUMMY       ' ' /* invalid data! */
#define NOINFO      '\0'/* no information -- data possibly
                         * from some old version of software
                         * or from stripped-down software...*/
/*
 * Possible values for the swapping field.
*/
#define SWAPPED     'S'  /* Little-Endian (Intel) */
#define UNSWAPPED   'U'  /* Big-Endian (Motorola) */

/*
 * Possible values for the signing field.
*/
#define SIGNED      'S'  /* Data's highest-order bit is sign bit */
#define UNSIGNED    'U'  /* No sign bit in data */

/*
 * Possible values for the caltype field.
 *
 * If uncalibrated, all other calibration-related fields are to be
 * ignored and may contain garbage.
 *
 * If either max or min values are calibrated, then the corresponding
 * "calmin" or "calmax" field should hold a reasonable floating point number.
 *
 * If the calibration type is FLOATINGPOINT, then the data themselves
 * are in float or double format (as opposed to integer format), and the
 * calmin and calmax fields should give the minimum and maximum
 * values occurring in the file.  The wordsize parameter will
 * determine whether these are 4-byte floats or 8-byte doubles.
 * In the unlikely event that the file contains floating-point values
 * untied to any specific calibration, use UNCAL_FLOATINGPOINT.
*/
#define CALIBRATED          'C'
#define UNCALIBRATED        'U'
#define ONLYMINCALIBRATED   'N'
#define ONLYMAXCALIBRATED   'X'
#define FLOATINGPOINT       'F'
#define UNCAL_FLOATINGPOINT 'f'

#define DATAFILE_TITLECHARS 82  /* 81 chars plus null terminator */
#define DATAFILE_STATIONCHARS 3 /* 2 chars plus null terminator */

struct datafilehdr {
   char magicstring[8], /* identifier, should be "DATA\0\0\0\0" */
        totalhdrs[3],   /* total number of 512-byte headers 
                         * incl. this one. (null-terminated ASCII) */
        abbrev[8],      /* 7 char abbreviation for title if any */
        stationcode[DATAFILE_STATIONCHARS], /* 2 char station code (PA, SU, etc.) */
        title[DATAFILE_TITLECHARS],      /* where the recording was made/title */
        month[3],       /* numeric WITH ZERO PLACEHOLDER,
                         * e.g. 03 = march, 10 = october, etc. */
        day[3],         /* numeric with zero placeholder */
        year[5],        /* 4-digit year, eg 1987 */
        hours[3],       /* numeric with zero placeholder */
        minutes[3],     /* numeric with zero placeholder */
        seconds[3],     /* numeric with zero placeholder */
        msec[4],        /* milliseconds later than above time,
                         * again with zero placeholders */
        sampling_period[15],	/* floating point number in seconds */
        samplebits[3],  /* BITS per data sample (e.g., "12") --
                         * this establishes min/max values */
        wordsize[2],    /* bytes reserved per data sample("1","2"...) */
        typemark,       /* see data type #defines above */
        swapping,       /* see swapping type #defines */
        signing,        /* see signing type #defines */
        caltype,        /* see calibration type #defines */
        calmin[MAX_CALSTRING_CHARS],     /* floating point min value if calibrated */
        calmax[MAX_CALSTRING_CHARS],     /* floating point max value if calibrated */
        calunits[40],   /* null-terminated units string (eg "volts") */
        recordsize[6],  /* suggested bytes to get in single read, usually 512 */
        sourcevers[9],  /* source version of code that wrote data */
        sourcesn[16],	/* serial number of unit that wrote data */
        fill[(512-253)];/* round out header to 512 bytes total.
                         * This region should not be filled with
                         * anything but nulls, so that later
                         * versions of this header will be
                         * compatible.  Any text comments should
                         * be placed in additional headers. */
};

#endif /* _DATAFILE_H_ */


/////////////////////////////////////////////////////////

#include <cmath>
#include <Rcpp.h>

// https://stackoverflow.com/q/13995266
// # include "datafile.h"
// # include "miniz.h"
typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint;

// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]

void MakeString(char*, uint32_t, FILE*);
uint8_t endianess(void);

/* Template C++
	https://stackoverflow.com/a/3824338
	https://stackoverflow.com/a/41014146
*/

/* Example:
	x = readMT('Helge/HDS00000.MT',100)
	x = readMT('Helge/HDS00000.MT')
	x = readMT('Helge/HDS00000.MT',10,10,'p')

	Input:
	len: length of required data to read
	start: delayed time in seconds
	slMode: S(samples in second); P(Points)

	Output:
	Data: read data
	Time: starting time of tagged file [YYYY-MM-DD H:M:S]
	Lag: = start in Input
	Rate: sampling rate of data [Hz]

	TODO: add lag time to start time (using functions in code.m)
	Other ways:
	https://stackoverflow.com/q/4781852
	https://stackoverflow.com/a/41613816
*/

// [[Rcpp::export]]
Rcpp::List readMT(std::string& filePath, uint64_t len=0,
										double start=0, char slMode = 'S', uint8_t sound_mode=0 ) 
{
	using namespace Rcpp ;
	FILE* mtFile;	//only samples in seconds (not Points supported)

	datafilehdr mtHeader = {{0}}; // stackoverflow.com/q/11152160
	// https://gist.github.com/hadley/6353939#file-read-file-cpp
	mtFile = fopen ( filePath.c_str() , "rb" ); // stackoverflow.com/a/7416473
	if (mtFile==NULL)
		Rcpp::stop("Cannot open file!\n");

	// obtain file size:
	std::fseek (mtFile, 0, SEEK_END);
	uint64_t i, lSize = std::ftell (mtFile);
	// Rcout <<"File size (byte): " << lSize << "\n" ;
	std::rewind (mtFile);

	/// read Header [https://stackoverflow.com/a/10252927]
	// Total of 253 bytes = 148 + 105
	MakeString(mtHeader.magicstring, 8, mtFile);
	MakeString(mtHeader.totalhdrs, 3,mtFile);
	MakeString(mtHeader.abbrev, 8,mtFile);
	MakeString(mtHeader.stationcode, 3,mtFile);
	MakeString(mtHeader.title,82,mtFile);
	MakeString(mtHeader.month, 3,mtFile);
	MakeString(mtHeader.day, 3,mtFile);
	MakeString(mtHeader.year, 5,mtFile);
	MakeString(mtHeader.hours, 3,mtFile);
	MakeString(mtHeader.minutes,3,mtFile);
	MakeString(mtHeader.seconds,3,mtFile);
	MakeString(mtHeader.msec,4,mtFile);
	MakeString(mtHeader.sampling_period,15,mtFile);
	MakeString(mtHeader.samplebits,3,mtFile);
	MakeString(mtHeader.wordsize,2,mtFile);

	MakeString(&mtHeader.typemark,1,mtFile);
	MakeString(&mtHeader.swapping,1,mtFile);
	MakeString(&mtHeader.signing,1,mtFile);
	MakeString(&mtHeader.caltype,1,mtFile);
	MakeString(mtHeader.calmin,15,mtFile);
	MakeString(mtHeader.calmax,15,mtFile);
	MakeString(mtHeader.calunits,40,mtFile);
	MakeString(mtHeader.recordsize,6,mtFile);
	MakeString(mtHeader.sourcevers,9,mtFile);
	MakeString(mtHeader.sourcesn,16,mtFile);


	// reset to the beginning of file
	std::rewind(mtFile);
	// Rcout <<"totalhdrs: " << mtHeader.totalhdrs << "\n" ;
	uint64_t headerSize =  512*std::stoi(mtHeader.totalhdrs);
	// Rcout <<"Header size (byte): " << headerSize << "\n" ;
	// Rcout <<"sampling_period (seconds): " << mtHeader.sampling_period << "\n" ;
	double srate = 1/std::stod(mtHeader.sampling_period);
	// Rcout << "Rate (Hz): " << srate << "\n" ;
	uint16_t wordSize = std::stoi(mtHeader.wordsize);
	// Rcout << "wordsize (Byte): " << wordSize << "\n" ;
	uint8_t status = std::fseek(mtFile,
															headerSize+wordSize*std::llround(start*srate),
															SEEK_SET);
	if (std::toupper(slMode) == 'P')
		status = std::fseek(mtFile,
													headerSize+wordSize*std::llround(start),
													SEEK_SET);
	if (status)
		Rcpp::stop("Cannot process file!\n");

	uint64_t nByte, rByte;
	if (len==0) {
		nByte = lSize-headerSize - wordSize*std::llround(start*srate);
	}	else {
		nByte = wordSize*std::llround(len*srate);
		if ( std::toupper(slMode)=='P' ) // not supported !
			nByte = wordSize*std::llround(len);
	}

	char* mt = (char*) std::malloc(nByte);
	if (mt == NULL)
		Rcpp::stop("Cannot allocate memory!\n");

	rByte = std::fread(mt, 1, nByte, mtFile);
	if ( rByte < nByte )
		Rcpp::warning("Warning: number of bytes read is smaller than required!\n");
	std::fclose(mtFile); // close File
	
	
	// swap if big-endian (x86/64 is little-endian)
	if ( (wordSize > 1) && (endianess() == 1) &&
				( std::toupper(mtHeader.swapping) != 'S' ) &&
				( std::toupper(mtHeader.swapping) != 'L' ) ){
		// https://stackoverflow.com/a/585274
		char* istart = mt;
		for (i= 0; i < rByte/wordSize; i++) {
			std::reverse(istart, istart+wordSize);
			istart += wordSize;
		} // if there are some bytes not fit into a wordSize
		if ( (rByte%wordSize >= 2) && (rByte%wordSize < wordSize) )
			std::reverse(istart, istart+rByte%wordSize);
	}
	
	// https://stackoverflow.com/q/24255051
	std::string TagTime = std::string(mtHeader.year) + "-" +
													std::string(mtHeader.month) + "-" +
													std::string(mtHeader.day) + " " +
													std::string(mtHeader.hours)+ ":" +
													std::string(mtHeader.minutes)+ ":" +
													std::string(mtHeader.seconds);
	if (std::stoi(mtHeader.msec) > 0)
		TagTime += "." + std::string(mtHeader.msec);
	if (sound_mode == 3)
		return List::create( Named("Time") = TagTime ) ;


	// https://stackoverflow.com/a/40446925
	NumericVector MtVect;
	IntegerVector MtVect_int;
	
// Rcout << "Typemark: " << mtHeader.typemark << "\n";
// Rcout << "Typemark: " << mtHeader.swapping << "\n";
// Rcout << "Caltype: " << mtHeader.caltype << "\n" ;
// Rcout << "Signing: " << mtHeader.signing << "\n" ;
// Rcout << "wordSize (byte) : " << wordSize << "\n\n" ;

	if ( std::toupper(mtHeader.caltype=='F') ) {
		switch (wordSize) {
			case 4: { // Float4
				float* mtData = (float*) mt;
				MtVect = NumericVector(mtData,mtData+nByte/wordSize); 
				break;	}
			case 8: { // Float8
				double* mtData = (double*) mt;
				MtVect = NumericVector(mtData,mtData+nByte/wordSize); 
				break;	}
			default: {
				Rcpp::stop("Invalid Float size!\n");
			}
		}
	}
	else if (std::toupper(mtHeader.signing)=='U') {
		switch (wordSize) {
			case 1: { 
				uint8_t* mtData = (uint8_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize);
				break; }
			case 2: 
			{ 
				uint16_t* mtData = (uint16_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize);
				break;}
			case 4: { 
				uint32_t* mtData = (uint32_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize);
				break;}
			case 8: { 
				uint64_t* mtData = (uint64_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize);
				break;}
			default: {
				Rcpp::stop("Invalid Unsigned Int size!\n");
			}
		}
	}
	else {
		switch (wordSize) {
			case 1:{
				int8_t* mtData = (int8_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize); 
				break;	}
			case 2:{
				int16_t* mtData = (int16_t*) mt;
				MtVect_int = IntegerVector(mtData, mtData+nByte/wordSize);	
				break;	}
			case 4:{
				int32_t* mtData = (int32_t*) mt;
				MtVect_int = IntegerVector(mtData,mtData+nByte/wordSize);	
				break;	}
			case 8:{
				int64_t* mtData = (int64_t*) mt;
				MtVect_int = IntegerVector(mtData, mtData+nByte/wordSize);
				break;	}
			default: {
				Rcpp::stop("Invalid Int size!\n");
			}
		}
	}

	bool noSep = true; // noSep = no seperator in calmin, calmax
	for (i=0; i<15; i++) {
		if ( (mtHeader.calmin[i]==' ') ||
					(mtHeader.calmin[i]==',') ||
					(mtHeader.calmin[i]==';')) {
			noSep = false; break;
		}
		if ( (mtHeader.calmax[i]==' ') ||
					(mtHeader.calmax[i]==',') ||
					(mtHeader.calmax[i]==';')) {
			noSep = false; break;
		}
	}
	double eps = std::pow(2.0,-52);
	double calmin = std::stod(mtHeader.calmin);
	double calmax = std::stod(mtHeader.calmax);
	double samplebits = std::stod(mtHeader.samplebits);
// Rcout << "calmax: " << calmax << "\n" ;
// Rcout << "calmin: " << calmin << "\n" ;
// Rcout << "eps: " << eps << "\n" ;

	double bitmin, bitmax ;
	if ( (noSep) && ( (calmin+eps) < calmax) && 
				std::toupper(mtHeader.caltype!='F') ) {
		
		if ( std::toupper(mtHeader.signing=='U') ) {
			bitmin = 0.0 ;
			bitmax = std::pow(2.0,samplebits) - 1.0;
		}
		else {
			bitmin = -std::pow(2.0,samplebits-1.0) ;
			bitmax =  std::pow(2.0,samplebits-1.0) - 1.0;	
		}
		
		double multiplier = ( calmax-calmin )/( bitmax-bitmin );
		MtVect = ( as<NumericVector>(MtVect_int) - bitmin ) * multiplier + calmin;
	}
	// Rcout << "multiplier: " << multiplier << "\n" ;

	if (sound_mode == 0)
		return List::create( // https://stackoverflow.com/a/3088744
													 Named("Data") = MtVect,
													 Named("Data_encode") = MtVect_int,
													 Named("Bit_per_pixel") = wordSize*8,
													 Named("Header_size") = headerSize,
													 Named("Time") = TagTime,
													 // Named("Lag")  = start,
													 Named("Rate") = srate   ) ;
	else if (sound_mode == 1)
		return List::create( // https://stackoverflow.com/a/3088744
													 Named("Data") = MtVect,
													 Named("Bit_per_pixel") = wordSize*8,
													 Named("Header_size") = headerSize,
													 Named("Time") = TagTime,
													 Named("Rate") = srate   ) ;
	else if (sound_mode == 2)
		return List::create( // https://stackoverflow.com/a/3088744
													 Named("Data_encode") = MtVect_int,
													 Named("Bit_per_pixel") = wordSize*8,
													 Named("Header_size") = headerSize,
													 Named("Time") = TagTime,
													 Named("Rate") = srate   ) ;
	else return NULL;
}


// https://stackoverflow.com/q/46218528#comment79401201_46218528
// https://stackoverflow.com/q/14589354
// https://stackoverflow.com/a/8971421
// http://gallery.rcpp.org/articles/creating-integer64-and-nanotime-vectors/
// there is nothing Rcpp-specific here, and there is not Rcpp "support" as there is not native integer64 in R we could lean on
// [https://stackoverflow.com/q/49015493#comment85065315_49015493]

void MakeString(char* p, uint32_t size, FILE* file) {
	if (size==1) {
		std::fread((void*) p, 1, 1, file); return;	}
	char* q0, *q, *r; bool null=false; uint32_t i;
	q0 = (char*)std::malloc(size); q = q0;
	if (q0==NULL) return;

	std::fread((void*) q0, 1, size, file);
	for (i=0; i<size; i++)
		if (*(q+i)==0) {
			null=true; break;
		}
	if (null && (i>0)) {
		r = q+i-1;
		// strtrim (Matlab)
		while ( ( (*q==' ') || (*q=='\t') ) && (q<r) ) q++;
		while ( ( (*r==' ') || (*r=='\t') ) && (r>q) ) r--;
		if (r>=q) std::memcpy(p,q,r-q+1);
	} std::free(q0);
}

// https://stackoverflow.com/a/4181991
uint8_t endianess() {
	int32_t n = 1;
	// little endian if true
	if(*(int8_t *)&n == 1) {
		// Rcpp::Rcout << "Little endian!\n";
		return 0;
	}
	else {
		// Rcpp::Rcout << "Big endian!\n";
		return 1;
	}
	// Ref: https://stackoverflow.com/q/8556927
}

// [[Rcpp::export]]
Rcpp::List FindDives(Rcpp::NumericVector depth, double DiveLevel, double MaxDepthLevel,
					double BottomPc, const int nDive = 15000)
{
	using namespace Rcpp;
	if (DiveLevel > MaxDepthLevel) {
		Rcpp::Rcout<< "\nWrong input: DiveLevel > MaxDepthLevel !\n";
		return Rcpp::List::create(
			Rcpp::Named("Start") = IntegerVector(0),
			Rcpp::Named("MaxDepth") = IntegerVector(0),
			Rcpp::Named("End") = IntegerVector(0) );
	}
	if (BottomPc > 1.0) {
		Rcpp::Rcout<< "\nWrong input: Percentage of Bottom > 1 !\n";
		return Rcpp::List::create(
			Rcpp::Named("Start") = IntegerVector(0),
			Rcpp::Named("MaxDepth") = IntegerVector(0),
			Rcpp::Named("End") = IntegerVector(0) );
	}

	int T = depth.size(), i, j, k=0;
	IntegerVector start(nDive), end(nDive);
	NumericVector MaxDepth(nDive);
	int s = (-1), md = 0, btstart, btend;
	double BottLevel, MaxD;
	/// Find Start/End of Dives >= DiveLevel
	for (i=0; i<T; i++ ) {
		// Find starts of new dives
		if (s < 0)
			if (depth[i] >= DiveLevel) {
				s = i; continue; }
		if (s >= 0) { // Start of Dive found!
			if (md == 0) { // Max Depth isn't defined yet
				if ((depth[i]== DiveLevel) && (DiveLevel!=MaxDepthLevel))
				{ s = i; continue; }
				if (depth[i] < DiveLevel) {
					if (DiveLevel!=MaxDepthLevel) s =-1;
					else {
						start[k] = s; end[k] = i+1;
						MaxDepth[k] = s+1; k++; s = -1;
					} continue;
				}
				if (depth[i]>= MaxDepthLevel) md = i;
			}
			else { // Max Depth found !
				if (depth[i] > depth[md]) md = i;
				else { // depth[md] > DiveLevel, always!
					if (depth[i] < DiveLevel) { // reach depth < DiveLevel
						start[k] = s+1; end[k] = i+1;
						MaxDepth[k] = md+1;
						k++; s = -1; md = 0;
					} else if ((depth[i]==DiveLevel) && (DiveLevel!=MaxDepthLevel)) {
						start[k] = s+1; end[k] = i+1;
						MaxDepth[k] = md+1;
						k++; s = -1; md = 0;
					}	}	}	}	}

	IntegerVector BottStart(k), BottEnd(k), BottomDur(k);
	NumericVector Ascend(k), Descend(k) ;
	/// Find time of start/end of Bottom Phase
	for (i=0; i < k; i++) {
		MaxD = depth[int(MaxDepth[i]-1)];
		MaxDepth[i] = MaxD;
		BottLevel = BottomPc*MaxD;
		if (BottLevel < DiveLevel) {
			BottStart[i] = start[i];
			BottEnd[i]   = end[i];
			BottomDur[i]  = end[i]-start[i];
		} else {
			j = start[i]-1;	btstart = -1; btend = end[i]-1;
			while ((j <= (end[i]-1)) && (depth[j] >= DiveLevel)) {
				if (btstart<0) {
					if (depth[j] >= BottLevel) {
						btstart = j;
						if (BottStart[i] == 0)
							BottStart[i] = btstart+1;
					}
				} else if ((depth[j]<BottLevel) || (j==(end[i]-1))) {
					BottomDur[i] += j-btstart;
					btend = j; btstart = -1;
				} j++;
			} BottEnd[i] = btend+1;
		} // https://stackoverflow.com/a/47246770
		Descend[i] = abs(mean(Rcpp::diff(depth[Rcpp::Range(start[i],BottStart[i])]))) ;
		Ascend[i]  = abs(mean(Rcpp::diff(depth[Rcpp::Range(BottEnd[i],end[i])]))) ;
	}
	// https://stackoverflow.com/a/3088744
	// https://stackoverflow.com/a/23175026
	return Rcpp::List::create(
		Rcpp::Named("Start")     = start[Rcpp::Range(0,k-1)],
		Rcpp::Named("End")       =   end[Rcpp::Range(0,k-1)],
		Rcpp::Named("BottStart") = BottStart,
		Rcpp::Named("BottEnd")   = BottEnd,
		Rcpp::Named("MaxDepth")  = MaxDepth[Rcpp::Range(0,k-1)],
		Rcpp::Named("BottDur")   = BottomDur,
		Rcpp::Named("DesSpeed")  = Ascend,
		Rcpp::Named("AscSpeed")  = Descend,
		Rcpp::Named("Duration")  = end[Rcpp::Range(0,k-1)]-start[Rcpp::Range(0,k-1)] );
	// For DataFrame: https://stackoverflow.com/a/8631854
}
