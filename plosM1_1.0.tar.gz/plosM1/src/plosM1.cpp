#define gamma_dist(x,k,theta) ( std::isnan(std::pow(x/theta,k-1)*std::exp(-x/theta)/(theta*std::tgamma(k))) ? (0) : (std::pow(x/theta,k-1)*std::exp(-x/theta)/(theta*std::tgamma(k))) )

#define DB_MIN_IEEE -DBL_MAX
#define LOG_MAX std::log(DBL_MAX)

#include <cmath>
#include <RcppArmadillo.h>

// https://stackoverflow.com/q/45362367#comment77685996_45362367
// using namespace Rcpp;

// https://teuder.gitbooks.io/introduction-to-rcpp/content/en/05_c++11.html
// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(RcppArmadillo)]]


// http://stackoverflow.com/a/14022668
// [[Rcpp::export]]
double log_sum(arma::rowvec x) { return logspace_sum(x.begin(),x.size());}

// Duration of no deep dive (how long)
// [[Rcpp::export]]
Rcpp::NumericVector noDdiveDur(Rcpp::DataFrame& data, double D)
{
	Rcpp::NumericVector depth = data["MaxDepth"];
	Rcpp::NumericVector ttime = data["TotalDur"];

	int T = depth.size(), i;
	// re-create vector of time from last depth
	Rcpp::NumericVector postDive = data["PostDiveDur"];
	Rcpp::NumericVector time     = Rcpp::clone(postDive);
	/* for (i=1; i<T; i++)
		if ( (depth[i] < D) && (depth[i-1] < D) )
			time[i] = time[i-1]+ttime[i]; */
	if (depth[0] < D) time[0] = ttime[0];
	for (i=1; i<T; i++)
		if (depth[i] < D) {
			if (depth[i-1] < D)
				time[i] = time[i-1]+ttime[i];
			else time[i] = ttime[i];
		}
	return time;
}


// [[Rcpp::export]]
Rcpp::IntegerVector ddiveInrow(Rcpp::NumericVector& MaxDepth, double D)
{
	int T = MaxDepth.size(), i;
	Rcpp::IntegerVector dive(T);

	if (MaxDepth[0] >= D) dive[0]=1;
	for (i=1; i<T; i++)
		if ( MaxDepth[i] >= D ) {
			if (MaxDepth[i-1] >= D)
				dive[i] = dive[i-1]+1;
			else dive[i]=1;
		}
	return dive;
}


#define asNum(x) Rcpp::as<Rcpp::NumericVector>(x)
#define asString(x) Rcpp::as<std::string>(x)
/// https://stackoverflow.com/a/3982397
#define SWAP(x, y) do { decltype(x) SWAP = x; x = y; y = SWAP; } while (0)

/// Convert List containing some sequence induced by string in their names to Matrix
arma::mat List2Mat(Rcpp::List& L, std::string u="")
{
	int i, c=0;
	Rcpp::StringVector N = L.names(); // stackoverflow.com/a/41894068
	Rcpp::IntegerVector Ind(N.size());

	for (i=0; i<N.size(); i++) // stackoverflow.com/a/2340309
		if ( (asString(N[i])).find(u) != std::string::npos ) Ind[c++] = i;
	if ((u=="") || (c==0)) return arma::mat();
	// https://stackoverflow.com/a/21251728
	// https://stackoverflow.com/a/5931163
	Rcpp::NumericMatrix M( c, asNum(L[Ind[0]]).size() );
	for (i=0; i<c; i++) M.row(i) = asNum(L[Ind[i]]);
	return Rcpp::as<arma::mat>(M);
}

/// Transition probabilities matrix: functions of the covariate deepDive
// [[Rcpp::export]]
arma::cube TransMat(int T, int N, Rcpp::List& L,
										arma::mat& M, arma::mat& S, arma::mat& S_d)
{
	using namespace Rcpp;
	
	arma::cube Omega(N,N,T);
	arma::rowvec eta(N), W(N), Y(N);
	int t, i, n, k;

	// Rcpp::NumericVector alpha1 = L["alpha1"];
	// Rcpp::NumericVector alpha2 = L["alpha2"];
	// Rcpp::NumericVector alpha3 = L["alpha3"];
	// Rcpp::NumericVector alpha4 = L["alpha4"];

	// Degree 3 of diurnal covariates
	arma::vec h[3];  for (i=0; i<3; i++) h[i]  = M.col(i);
	arma::vec s[3];  for (i=0; i<3; i++) s[i]  = S.col(i);
	arma::vec sd[3]; for (i=0; i<3; i++) sd[i] = S_d.col(i);
	
	int p = 7+N;
	NumericVector theta[N][N-1];
	for (n=0; n<N; n++)
		for (i=0; i<=(N-2); i++, p++)
			theta[n][i] = L[p];
		
	NumericVector delta[N][N-1];
	for (n=0; n<N; n++)
		for (i=0; i<=(N-2); i++, p++)
			delta[n][i] = L[p];

	Rcpp::NumericVector alpha;
	eta[N-1] = 0; 
	for(t=0 ; t<T ; t++) {
		for (n=0; n<N; n++) { // n: index of current state
			alpha = L[7+n];
			if ( n <= (N-1)/2 ) { // 'shallow' states
				for (i=0; i<=(N-2); i++) { // i: index of switched state
					eta[i] = alpha[i] ; // alpha1, alpha2, alpha3, alpha4
					for (k=0; k<3; k++) 
						eta[i] += theta[n][i][k]*s[k][t]+delta[n][i][k]*h[k][t] ;
				}
				Y.fill(log_sum(eta)); W = arma::exp(eta-Y);
				for (i=0, k=0; i<=(N-2); i++, k++) {
					if (i==n) k++;
					Omega(n,k,t) = W[i];
				}
			} else { // 'deep' states
				for (i=0; i<=(N-2); i++) { // i: index of switched state
					eta[i] = alpha[i] ; // alpha1, alpha2, alpha3, alpha4
					for (k=0; k<3; k++) 
						eta[i] += theta[n][i][k]*sd[k][t]+delta[n][i][k]*h[k][t] ;
				}
				Y.fill(log_sum(eta)); W = arma::exp(eta-Y);
				for (i=0, k=0; i<=(N-2); i++, k++) {
					if (i==n) k++;
					Omega(n,k,t) = W[i];
				}
			}
				
			Omega(n,n,t)= W[N-1];
		}
	}

	return Omega;
}

// [[Rcpp::export]]
double logLE_cpp(Rcpp::DataFrame& data,
				Rcpp::NumericVector& muMD, Rcpp::NumericVector& sgMD,
				Rcpp::NumericVector& muDT, Rcpp::NumericVector& sgDT,
				Rcpp::NumericVector& muPD, Rcpp::NumericVector& sgPD,
				Rcpp::NumericVector& rho,
				Rcpp::NumericVector& vecC, Rcpp::IntegerVector& dimC, int N)
{
	Rcpp::NumericVector MD = data["MaxDepth"];
	Rcpp::NumericVector MaxDepth = Rcpp::clone(MD)-19.5;
	Rcpp::NumericVector Duration = data["Duration"];
	Rcpp::NumericVector MDxDr    = 2*M_PI*MaxDepth*Duration;
	Rcpp::NumericVector PostDive = data["PostDiveDur"];
	int T = MaxDepth.size();
	// re-create array of transition probabilities
	arma::cube trMat_all(vecC.begin(), dimC[0], dimC[1], dimC[2], false);

	// matrix of conditional joint probabilities
	arma::mat allProbs(T,N);
	allProbs.zeros();
	int t, i; double a, b, y0, y, x1, x2, x3;
	// https://svn.r-project.org/R/trunk/src/nmath/dpois.c
	// https://svn.r-project.org/R/trunk/src/nmath/dgamma.c
	for(t=0; t<=(T-1); t++) {
		x1 = MaxDepth[t]; x2 = Duration[t];
		x3 = PostDive[t];
		for (i=0; i<=(N-1); i++) {
			y0 = sqrt(1-rho[i]*rho[i])*MDxDr[t];
			a = (log(x1)-muMD[i])/sgMD[i];
			b = (log(x2)-muDT[i])/sgDT[i];
			y = y0*sgMD[i]*sgDT[i]*exp((a*a+b*b-2*rho[i]*a*b)/(2*(1-rho[i]*rho[i])));
			allProbs(t,i) = 1/y*R::dlnorm(x3,muPD[i],sgPD[i],0);
		}
	}
	// initially in state 1
	arma::rowvec v(N);
	// v.zeros(); v(0) = 1;
	v.fill(1.0/N);
	v = v%allProbs.row(0);
	arma::mat Omega(N,N);
	// forward algorithm
	double llk = 0;
	for (t=1; t<=(T-1); t++) {
		Omega = trMat_all.slice(t-1);
		v = v*Omega%allProbs.row(t);
		llk = llk+log(sum(v));
		v = v/sum(v);
	}
	return -llk;
}

