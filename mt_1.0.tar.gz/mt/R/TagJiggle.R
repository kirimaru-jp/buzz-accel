#### Tag Jiggle ####
library(signal); library(matrixStats); options(digits = 8)

logVar = function(x)
	cat(paste('\t', deparse(substitute(x)),'=',
			  paste(round(x,digits = 6),collapse=', '),'\n' ))

DIM = function(x)
	if(is.vector(x)) {c(length(x),1)} else dim(x)

# Matlab-based buffer function
buffer = function(x,n,p) { # nodelay
	if(length(x) >= n) {
		col = ceiling((length(x)-n)/(n-p))+1
		y = matrix(0,n,col); s = (n-p)*seq(0,col-1)
		for (i in 1:n)	y[i,] = x[i+s] 
	}	else {
		y = x
	}
	y[is.na(y[,col]),col] = 0; y
}

TagJiggle = function(A,Afs,fs,
					 freq=c(10,90),bin=0.5,
					 Atime=(seq_len(DIM(A)[1])-1)/(86400*Afs),
					 DN=seq(0,(DIM(A)[1]-1)/Afs,1/fs)/(86400) ) {
	##### Comments #####
	# Distributed with Cade et al. 2018, Determining forward speed from
	# accelerometer jiggle in aquatic environments, Journal of Experimental
	# Biology, http://jeb.biologists.org/lookup/doi/10.1242/jeb.170449

	# Calculates the root mean square (RMS) amplitude of accelerometer jiggle
	#
	# Inputs required are:
	# A = calibrated high sample rate acc data (>100 Hz best for speed).  If
	#     dim(A,2) > 1, the magnitude of the accelerometer is calculated
	#     before finding the amplitude of tag jiggle
	# Afs = Sample rate of A
	# fs = downsampled rate of output file
	# (usually would match downsampled rate of pitch, roll etc.)
	# Inputs (optional):
	# freq = bandpass filtering to do on acceleration file (enter [] to use defaults from Cade et al.)
	#        default: [10 90].  If freq(2)>Afs/2, only a highpass fiter is used
	#        at freq(1)
	# bin = bin size over which to average data (in seconds);
	#       default: 0.5
	# Atime = matlab datenumbers with time points for each value in A
	# (With DN, useful for ensuring exact time correlations between hf and lf data).
	# Default: Create variable using a random start time and Afs.
	# DN = matlab datenumbers of time points at which an RMS value is desired.
	#       DN usually matches the time stamps of every point in a decimated
	#       prh file for which speed will be calculated.  Default: Create
	#       variable using a random start time and fs.

	# Output "JiggleRMS" will be the same size as DN (the size of the data at fs)
	#
	# Based on DTAG toolbox file d3rms, by Stacy DeRuiter and
	# Alison Stimpert, and utilizes fir_nodelay, by Mark Johnson, available at
	# https://www.soundtags.org/dtags/dtag-toolbox/

	##### Code ####

	# logVar(head(Atime))
	# logVar(head(DN)); logVar(DIM(DN))

	highpass = (freq[2] >= Afs/2)
	if (NCOL(A) > 1) {
		magA = sqrt(rowSums(A^2)) 
	}	else { 
		magA = abs(A) 
	}
		# logVar(head(magA)); logVar(DIM(magA))
		# logVar(freq)
		# logVar(freq[1]/(Afs/2))

	if (highpass) {
		# filter the accelerometer signal < freq(1)
		Afilt = fir_nodelay(magA,128,freq[1]/(Afs/2),'high')	
	}	else {
		# filter the accelerometer signal between freq(1) and freq(2)
		Afilt = fir_nodelay(magA,128, c(freq[1]/(Afs/2),freq[2]/(Afs/2)),qual='pass')
	}
		# logVar(head(Afilt$y)); logVar(DIM(Afilt$y))
	# analyze bin secs of acclerometer data at a time
	n = round(Afs*bin); #logVar(n)
	# Allow for 1/fs samples of overlap...so the one analysis window slides
	# forward by 1/fs sec per time (i.e. 10 Hz data returns 10 Hz data)
	nov = round(n-(1/fs*Afs)); #logVar(nov)
	if (nov - (n-(1/fs*Afs)) > 0.01) # if your bin size isn't an integer, error
		error('Non integer bin size.
			  Trying to slide by 1/fs*Afs, but 1/fs*Afs is not an integer')

	# n is the number of samples per chunk; nov is the amount of overlap in
	# samples, goes until the last complete bin can be put in a chunk
		# logVar(DIM(Afilt$y))
	X = buffer(Afilt$y,n,nov)
		# logVar(DIM(X)); logVar(head(X[,1:3]))
	# Start half bin seconds in (so that the jiggle bins are centered and are
	# bin seconds long each) and go every 1/fs second, that should get in the
	# middle of the buffer
		# logVar(DIM(Atime))
		# logVar(round(Afs*bin/2))
		# logVar(length(Atime))
		# logVar(round(Afs/fs))

	Xtime = Atime[seq(round(Afs*bin/2),length(Atime),by=round(Afs/fs))]
		# logVar(head(Xtime)); logVar(DIM(Xtime))
	Xtime = Xtime[1:dim(X)[2]]
	RMS   = 20*log10(colSds(X))
		# logVar(head(RMS)); logVar(DIM(RMS))
	JiggleRMS = rep(NaN,length(DN)); k = 1
	j = which.min(abs(DN-(Xtime[1]-1/fs/2/86400))); JiggleRMS[j] = RMS[k]
		# logVar(j); logVar(length(DN)) ; logVar(fs); logVar(length(Xtime))
	for (k in 1:length(Xtime)) {
		# k = 1
		# find the times that are within 1/fs/2 seconds of Xtime[k]
			# logVar(DN[j:min(j+fs,length(DN))])
			# logVar(DIM(DN[j:min(j+fs,length(DN))]) )
		val = Xtime[k]+1/fs/2/86400
			# logVar(val)
		j2 = (j-1)+which( (DN[j:min(j+fs,length(DN))]- val) <= 0 )
		if (identical(j2, integer(0))) {
			j  = min( which( abs(DN-(Xtime[k]-1/fs/2/86400)) ) )
			j2 = min( which( abs(DN-val) ) ) 
		}	else {
			j2 = max(j2)
		}
		JiggleRMS[j:j2] = RMS[k]; j = j2+1
	}
		logVar(head(JiggleRMS)); logVar(DIM(JiggleRMS))
		logVar(JiggleRMS[10000:10006])

	return (JiggleRMS)
}


# Delay-free filtering using a linear-phase (symmetric) FIR filter
# followed by group delay correction.
# Delay-free filtering is needed when the relative timing between signals
# is important
# e.g. when integrating signals that have been sampled at different rates.
fir_nodelay = function(x, n, fc, qual='low'){
	# input checking
	# ================================================================
	# make sure x is a column vector or matrix
	if (!(sum(class(x) %in% c('matrix', 'vector'))))
		x = as.matrix(x)

	if (is.vector(x)) x = as.matrix(x, nrow=length(x))
	# in case of multi-channel data, make sure matrix rows are samples and columns are channels
	if (dim(x)[2] > dim(x)[1]) x = t(x)
	# make sure n is even to ensure an integer group delay
	n = floor(n/2)*2


	# generate fir filter
	# ============================================================
	h = signal::fir1(n=n,w=fc, type=qual)

	# append fake samples to start and end of x to absorb filter delay
	# (output from these will be removed before returning result to user)
	nofsampling_rate = floor(n/2)
	top_pad = matrix(x[nofsampling_rate:2,], ncol=NCOL(x))
	bot_pad = matrix(x[(NROW(x)-1):(NROW(x)-nofsampling_rate),], ncol=NCOL(x))
	x_pad = rbind(top_pad, x, bot_pad)
		# logVar(DIM(x_pad))

	# filter the signal
	# ============================================================
	# apply filter to padded signal
	y = matrix(0, nrow=NROW(x_pad), ncol=NCOL(x_pad))
		# logVar(DIM(y))
	for (c in 1:NCOL(x_pad))
		y[,c] = as.matrix(signal::filter(x=x_pad[,c], filt=h),
											nrow=NROW(x_pad))

	# account for filter ofsampling_ratet (remove padding)
	y = y[n-1+(1:NROW(x)),]
		# logVar(tail(n-1+(1:NROW(x))))

	return(list(y=y, h=h))
}


fir_nodelayArma = function(x, n, fc, qual='low'){
	# input checking
	# ================================================================
	# make sure x is a column vector or matrix
	if (!(sum(class(x) %in% c('matrix', 'vector'))))
		x = as.matrix(x)

	if (is.vector(x)) x = as.matrix(x, nrow=length(x))
	# in case of multi-channel data, make sure matrix rows are samples and columns are channels
	if (dim(x)[2] > dim(x)[1]) x = t(x)
	# make sure n is even to ensure an integer group delay
	n = floor(n/2)*2


	# generate fir filter
	# ============================================================
	h = signal::fir1(n=n,w=fc, type=qual)

	# append fake samples to start and end of x to absorb filter delay
	# (output from these will be removed before returning result to user)
	nofsampling_rate = floor(n/2)
	top_pad = matrix(x[nofsampling_rate:2,], ncol=NCOL(x))
	bot_pad = matrix(x[(NROW(x)-1):(NROW(x)-nofsampling_rate),], ncol=NCOL(x))
	x_pad = rbind(top_pad, x, bot_pad)
		# logVar(DIM(x_pad))

	# filter the signal
	# ============================================================
	# apply filter to padded signal
	y = matrix(0, nrow=NROW(x_pad), ncol=NCOL(x_pad))
		# logVar(DIM(y))
	for (c in 1:NCOL(x_pad))
		# y[,c] = as.matrix(signal::filter(x=x_pad[,c], filt=h),
		# 				  nrow=NROW(x_pad))
		y[,c] = as.matrix(filterArma(x=x_pad[,c], filt=h, a=1),
						  nrow=NROW(x_pad))

	# account for filter ofsampling_ratet (remove padding)
	y = y[n-1+(1:NROW(x)),]
		# logVar(tail(n-1+(1:NROW(x))))

	return(list(y=y, h=h))
}


# Octave/Matlab-compatible filter function
# y = filter (b, a, x)
filterArma = function(filt, a, x, init, init.x, init.y, ...) {
	if(missing(init.x))
		init.x = c(rep(0, length(filt) - 1))
	if(length(init.x) != length(filt) - 1)
		stop("length of init.x should match filter length-1 = ", length(filt)-1)
	if(missing(init) && !missing(init.y))
		init = rev(init.y)
	if(all(is.na(x)))
		return(x)
	if (length(filt)) {
		# x1 = stats::filter(c(init.x, x), filt/a[1], sides=1)
		# library(Rcpp); sourceCpp('convolution.cpp')
		x1 = convArm(c(init.x, x), filt/a[1])[1: (length(x)+length(filt)-1) ]
		x1[1:(length(filt)-1)] = NA
		if(all(is.na(x1)))
			return(x)
		x = na.omit(x1, filt/a[1], sides=1)
	}
	if (length(a) >= 2)
		x = stats::filter(x, -a[-1]/a[1], method="recursive", init=init)
	x
}


fir_nodelay_conv = function(x, n, fc, qual='low'){
	# input checking
	# ================================================================
	# make sure x is a column vector or matrix
	if (!(sum(class(x) %in% c('matrix', 'vector'))))
		x = as.matrix(x)

	if (is.vector(x)) x = as.matrix(x, nrow=length(x))
	# in case of multi-channel data, make sure matrix rows are samples and columns are channels
	if (dim(x)[2] > dim(x)[1]) x = t(x)
	# make sure n is even to ensure an integer group delay
	n = floor(n/2)*2


	# generate fir filter
	# ============================================================
	h = signal::fir1(n=n,w=fc, type=qual)

	# append fake samples to start and end of x to absorb filter delay
	# (output from these will be removed before returning result to user)
	nofsampling_rate = floor(n/2)
	top_pad = matrix(x[nofsampling_rate:2,], ncol=NCOL(x))
	bot_pad = matrix(x[(NROW(x)-1):(NROW(x)-nofsampling_rate),], ncol=NCOL(x))
	x_pad = rbind(top_pad, x, bot_pad)
		# logVar(DIM(x_pad))

	# filter the signal
	# ============================================================
	# apply filter to padded signal
	y = matrix(0, nrow=NROW(x_pad), ncol=NCOL(x_pad))
		# logVar(DIM(y))
	for (c in 1:NCOL(x_pad))
		# y[,c] = as.matrix(signal::filter(x=x_pad[,c], filt=h),
		# 				  nrow=NROW(x_pad))
		y[,c] = as.matrix(filter_conv(x=x_pad[,c], filt=h, 
																	a=1),
											nrow=NROW(x_pad) )

	# account for filter ofsampling_ratet (remove padding)
	y = y[n-1+(1:NROW(x)),]
		# logVar(tail(n-1+(1:NROW(x))))

	return(list(y=y, h=h))
}


# Octave/Matlab-compatible filter function
# y = filter (b, a, x)
filter_conv= function(filt, a, x, init, init.x, init.y, ...) {
	if(missing(init.x))
		init.x = c(rep(0, length(filt) - 1))
	if(length(init.x) != length(filt) - 1)
		stop("length of init.x should match filter length-1 = ", length(filt)-1)
	if(missing(init) && !missing(init.y))
		init = rev(init.y)
	if(all(is.na(x)))
		return(x)
	if (length(filt)) {
		# x1 = stats::filter(c(init.x, x), filt/a[1], sides=1)
		x1 = convolve(c(init.x,x), rev(filt)/a[1],type='o')[1: (length(x)+length(filt)-1) ]
		x1[1:(length(filt)-1)] = NA
		if(all(is.na(x1)))
			return(x)
		x = na.omit(x1, filt/a[1], sides=1)
	}
	if (length(a) >= 2)
		x = stats::filter(x, -a[-1]/a[1], method="recursive", init=init)
	x
}


#  Pitch and roll estimation from triaxial accelerometer data.
# http://animaltags.org/doku.php?id=tagwiki:tools:processing:a2pr
a2pr = function(A, sampling_rate=NULL, Fc=NULL) {
	# input checks
	if (is.list(A)) {
		sampling_rate = A$sampling_rate
		A = A$data
	}

	# catch the case of a single acceleration vector
	if (min(c(NROW(A), NCOL(A))) == 1)
		A = matrix(A, nrow=1)
	if (!is.null(Fc))
		A = fir_nodelay(A, round(4/Fc), Fc /(sampling_rate/2))$y

	v = sqrt(rowSums(A^2))
	# compute pitch and roll
	p = asin(A[,1]/v)
	r = Re(atan2(A[,2], A[,3]))
	list(pitch = p, roll = r)
}

#  Estimate the vertical velocity
# http://animaltags.org/doku.php?id=tagwiki:tools:processing:depth_rate
depth_rate = function(p, fs, fc) {
	if (missing(p))
    stop("input for p is required")
		
	if (is.list(p)) {
		if (nargs() > 1) {
				fc = fs
		} else {
				fc = c()
		}
		fs = p$fs; p = p$data
	} else {
		if(missing(fc))
				fc = 0.2
	}
	nf = round(4*fs/fc)
	#use central differences to avoid a half sample delay
	x1 = p[2] - p[1]
	x2 = (p[3:length(p)] - p[1:(length(p)-2)])/2
	x3 = p[length(p)] - p[length(p)-1]
	X = c(x1, x2, x3)
	diffp = X * fs

	#low pass filter to reduce sensor noise
  fir_nodelay(diffp, nf, fc/(fs/2))$y
}

# The decimation factor, df, is just what you would divide the sampling
# rate of the raw data by to get the sampling rate you want. That is, if
# you have 200 Hz data and want 10 Hz data, the df would be 20.	If At is
# your raw acceleration data 3-column matrix, to decimate just do:
# At = decdc(At,df)
# (with df whatever integer value you want).
# We collect our accelerometer data at 400 Hz and downsample to 10 Hz
# (so df = 40) before calculating pitch, roll, etc.
decdc = function(x,df) {

	library(Rcpp); library(RcppArmadillo)
	if (missing(df))
		stop("df is a required input!")
	if (is.list(x)) {
		X = x;	x = X$data	
	}	else {
		X = NULL
	}
	if (NROW(x) < 2)
		warning("Make sure that you have input your data as a column vector or a matrix!")
	if (is.vector(x) && !is.matrix(x)) {
		x = matrix(x, ncol=1) # if data is not a matrix, make it one	
	}	else {
		stop('Input need to be vector or matrix!')	
	}
	if (round(df) != df) {
		df = round(df)
		warning("decdc needs integer decimation factor")
	}
	flen = 12*df
		logVar(flen)
	h = as.vector(signal::fir1(flen, 0.8/df))
	xlen = NROW(x)
		logVar(xlen)
	#ensures that the output samples coincide with every df of the input samples
	dc = flen + floor(flen/2) - round(df/2) + seq(df, xlen, df)
	y = matrix(0, nrow = length(dc),ncol = NCOL(x))
		logVar(NCOL(x))	; logVar(NROW(x))
		# logVar(str(x))
	
	# sourceCpp('convolution.cpp')
	for (k in 1:NCOL(x)) {
		abc = 2*x[1,k] - x[1+(seq((flen+1),1,-1)), k]
		bcd = x[,k]
		cde = 2*x[xlen,k] - x[xlen-c(1:(flen+1),k)]
		v = convArm( h, c(abc, bcd, cde) )
		# v = signal::conv(h, c(abc, bcd, cde))
		# v = pracma::conv(h, c(abc, bcd, cde))
		# results identical and signal is a bit faster? SDR
		y[,k] = v[dc]
	}

	if (is.list(X)) {
		X$data = y
		X$sampling_rate = X$sampling_rate/df
		h = sprintf('decdc(%d)',df)
		if ('history' %in% names(X) | is.null(X$history)) {
			X$history = h 
		}	else {
			X$history = c(X$history, h)	
		}
		y = X
	}
	return(y)
}


## Use fir_nodelayArma, idea from depth_rate() function above,
## use fir_nodelayArma, faster version of fir_nodelay
## See: https://dsp.stackexchange.com/a/16561
## https://github.com/cran/signal/blob/master/R/decimate.R
decimate_no_delay_arma = function(x, q, sampling_rate = q,
													n = if (ftype == "iir") 8 else 30,
													ftype = "fir")
{
  if (q != round(q))
    stop("decimate only works with integer q.")

  fir = ftype == 'fir'

  if (fir) {
    # b = fir1(n, 1/q)
    # y <- fftfilt(b, x)
    y =	fir_nodelayArma( x, round( n*q/sampling_rate ), 1/q )$y

  }	# else { # don't support IIR
    # y <- filtfilt(cheby1(n, 0.05, 0.8/q), x)
  # }
  
  (y[seq(1, length(x), by = q)])
}

