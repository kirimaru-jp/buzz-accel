#include <cmath>
#include <RcppArmadillo.h>

// https://teuder.gitbooks.io/introduction-to-rcpp/content/en/05_c++11.html
// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(RcppArmadillo)]]

#define asNum(x) Rcpp::as<NumericVector>(x)
#define asString(x) Rcpp::as<std::string>(x)
/// https://stackoverflow.com/a/3982397
#define SWAP(x, y) do { decltype(x) SWAP = x; x = y; y = SWAP; } while (0)
	
// https://stackoverflow.com/a/3437484
#define Max(a,b) \
 ({ __typeof__ (a) _a = (a); \
		 __typeof__ (b) _b = (b); \
	 _a > _b ? _a : _b; })

#define Min(a,b) \
 ({ __typeof__ (a) _a = (a); \
		 __typeof__ (b) _b = (b); \
	 _a < _b ? _a : _b; })
	 

// Max integer value in R minus 1
#define MAX_INT_R (int)(2147483646) // (2147483647-1)

 // https://stackoverflow.com/a/1932371
inline bool pnpoly(Rcpp::NumericVector&, Rcpp::NumericVector&, double, double);

struct Point{double x; double y; };
#define dist(v,w) sqrt( pow(v.x-w.x,2.0)+pow(v.y-w.y,2.0) )
#define Dot(v,w) v.x*w.x + v.y*w.y

// http://stackoverflow.com/a/14022668
// [[Rcpp::export]]
double log_sum(arma::rowvec x) { return logspace_sum(x.begin(),x.size());}

/* Compare with signal package -> more accurate
// library(signal)
// conv(c(1,2,3), c(1,2)) # [1] 1 4 7 6
// conv(c(1,2), c(1,2,3)) # [1] 1 4 7 6
// conv(c(1,-2), c(1,2)) # 1.000000e+00 -2.960595e-16 -4.000000e+00
//
// library(Rcpp); library(RcppArmadillo); sourceCpp('convolution.cpp')
// 	u1 = as.vector(convArm(c(1,2,3), c(1,2))) # [1] 1 4 7 6
// convArm(c(1,2), c(1,2,3)) # [1] 1 4 7 6
// convArm(c(1,-2), c(1,2)) # 1    0   -4
*/
// [[Rcpp::export]]
arma::vec convArm(arma::rowvec& A, arma::rowvec& B) {
	// http://arma.sourceforge.net/docs.html#conv
	// The orientation of the result vector is the same as the orientation of A
	// (ie. either column or row vector)
	// The shape argument is optional; it is one of:
	// 	   "full": full convolution (default setting), with the size equal to A.n_elem + B.n_elem - 1
	// 	   "same": central part of the convolution, with the same size as vector A
	// The convolution operation is also equivalent to FIR filtering
	arma::rowvec x = arma::conv( A, B );
	return x.t() ;
	// return arma::conv(A, B, "same");
}


// [[Rcpp::export]]
arma::vec fir(arma::rowvec& A, arma::rowvec& filt) {
	// http://arma.sourceforge.net/docs.html#conv
	// The orientation of the result vector is the same as the orientation of A
	// (ie. either column or row vector)
	// The shape argument is optional; it is one of:
	// 	   "full": full convolution (default setting), with the size equal to A.n_elem + B.n_elem - 1
	// 	   "same": central part of the convolution, with the same size as vector A
	// The convolution operation is also equivalent to FIR filtering
	arma::rowvec x = arma::conv( A, filt );
	return x.t() ;
}


// [[Rcpp::export]]
Rcpp::NumericVector rms(arma::rowvec& x, Rcpp::NumericVector& ind) {
	uint64_t i, N = ind.size() ;
	Rcpp::NumericVector r(N-1);
	// Rcpp::Rcout << "N = " << N << "\n";

	for (i=0; i<(N-1); i++) {
		// Rcpp::Rcout << "i = " << i << ": " << x.subvec( ind(i), ind(i+1)-1 ) << "\n";
		r[i] = std::sqrt(arma::mean(
				arma::square(x.subvec( ind(i), ind(i+1)-1 )) ) ) ;
	}
	return r;
}


// Shortest distance between a point and a line segment
// https://stackoverflow.com/a/1501725
double minDistance(Point p, Point u, Point v) {
	// Return minimum distance between line segment vw and Point p
	const double l2 = dist(v,u)*dist(v,u);  // i.e. |u-v|^2 -  avoid a sqrt
	if (l2 == 0.0) return dist(p,u);   // v == u case
	// Consider the line extending the segment, parameterized as tv + (1-t)u.
	// We find projection of Point p onto the line.
	// It falls where t = [(p-u) . (v-u)] / |v-u|^2
	// We clamp t from [0,1] to handle Points outside the segment uv.
	Point pu; pu.x = p.x-u.x; pu.y = p.y-u.y;
	Point vu; vu.x = v.x-u.x; vu.y = v.y-u.y;
	double t = fmax(0.0, fmin(1.0, Dot(pu,vu)/l2));
	Point proj;
	proj.x = t*v.x + (1-t)*u.x;  // Projection falls on the segment
	proj.y = t*v.y + (1-t)*u.y;  // Projection falls on the segment
	return dist(p, proj);
}

// Distance to coast
// [[Rcpp::export]]
Rcpp::NumericVector distCoast (Rcpp::NumericVector& P, 
									Rcpp::NumericVector& X, Rcpp::NumericVector& Y, 
									int coast_ID = 2147483646 ) 
{
	// Here coast_ID is the one in R minus 1, 
	// because C/C++ array/vector start from 0, and R start from 1
	// (avoid index out of bound)
	
	if (coast_ID < 0)
		Rcpp::stop( " coast_ID < 0 " ) ;

	Point p = {P(0),P(1)}, u, v;
	int i, N = X.size();
	int k1, k2, K ;
	
	Rcpp::NumericVector d1(1);
	if (N==1) {
		u = {X(0),Y(0)};
		d1(0) = dist(p,u);
		return d1;
	}
	
	// Compute for only TWO coasts of ID "coast_ID"
	// (k1, k1+1) and (k1, k1-1)
	if ( coast_ID < MAX_INT_R ) {
		K = 1 ;
		k1 = coast_ID ;
		if ( coast_ID < (N-1) )
			k2 = k1+1 ;
		else 	// If it's the "last" point (largest order), connect it to the first point to make a coast, i.e. "circular" - coast_ID = N-1
			k2 = 0 ;
	}
	else { // Compute for all coast of the zone
		// k1 = 0 ; k2 = N-1 ; 
		K = N ;
	}

	Rcpp::NumericVector d(K), e(K) ;
	double l2, a1, a2, a3 ;
	Point pu, pv, uv;
	
	// "Goto" can't skip over initializations of variables
	// https://stackoverflow.com/a/14274292
	if (K == N)
		goto WHOLE_SHORE_ZONE ;


	u = {X(k1),Y(k1)}; v = {X(k2),Y(k2)};
	pu.x = u.x-p.x; pu.y = u.y-p.y;
	pv.x = v.x-p.x; pv.y = v.y-p.y;
	uv.x = v.x-u.x; uv.y = v.y-u.y;
		
	a1 = Dot(uv,uv); a2 = Dot(pu,pu);	a3 = Dot(pv,pv);
	l2 = std::sqrt(a1);  // i.e. |u-v|_2
	if (l2 < 1e-14) // if u is too close to v
		d(0) = std::sqrt(a2); 
	else { // Collorary from Pythagorean theorem
		if (  ( a1+a3<a2 ) || ( a1+a2<a3 ) ) // altitude outside uv
			d(0) = Min(std::sqrt(a2),std::sqrt(a3));
		else // Shoelace formula
			d(0) = std::abs((pu.x)*(pv.y)-(pv.x)*(pu.y))/l2 ;
	}
	
	return d ;


WHOLE_SHORE_ZONE:
	for (i=0; i<=(N-1); i++) {
		u = {X(i),Y(i)};
		if ( i < (N-1) )
			v = {X(i+1),Y(i+1)} ;
		else // last point of Zone (i.e. polygon)
			v = {X(0),Y(0)} ;
		
		pu.x = u.x-p.x; pu.y = u.y-p.y;
		pv.x = v.x-p.x; pv.y = v.y-p.y;
		uv.x = v.x-u.x; uv.y = v.y-u.y;
				
		a1 = Dot(uv,uv); a2 = Dot(pu,pu);	a3 = Dot(pv,pv);
		l2 = std::sqrt(a1);  // i.e. |u-v|_2
		if (l2 < 1e-14) // if u is too close to v
			d(i) = std::sqrt(a2); 
		else { // Collorary from Pythagorean theorem, or Law of Cosine
			if (  ( a1+a3<a2 ) || ( a1+a2<a3 ) ) // altitude outside uv
				d(i) = Min(std::sqrt(a2),std::sqrt(a3));
			else // Shoelace formula
				d(i) = std::abs((pu.x)*(pv.y)-(pv.x)*(pu.y))/l2 ;
		}
	}
	
	return d;
}


// Distance to coast, implement "raw" test to speed up 
// Set default max speed is 10 m/s, it's safe !
// [[Rcpp::export]]
Rcpp::DataFrame path_to_coast(
Rcpp::DataFrame& path, Rcpp::List& Shores, 
Rcpp::StringVector& nearest_zone_ID, double Max_Speed = 10.0  )
{
	using namespace Rcpp;
	std::string s ;
	int N = path.nrow() ;	
	int n = nearest_zone_ID.size() ;	
	int k, i, j;
		
	NumericVector whale_pos(2), beach_x, beach_y;
	DataFrame beach;
	NumericVector d(n), p(n), X, Y ;
	X = path["X"]; Y = path["Y"];
	NumericVector y(N), P(N), D(N)  ;
	StringVector ID(N) ;
	double d_min = 0.0 ; // nearest distance of last position
	int on_land_ID ;

	for (i = 0; i < N; i++) {
		whale_pos(0) = X(i);	whale_pos(1) = Y(i);	
		on_land_ID = -1 ;
		for (k = 0; k < n; k++) {
			// https://stackoverflow.com/a/8422324
			s = Rcpp::as<std::string>( nearest_zone_ID(k) ) ;
			beach = Shores[s] ;
			beach_x = beach["X"] ; beach_y = beach["Y"] ;
			// If inside this zone, it's on land so save this ID			
			if ( pnpoly(beach_x, beach_y, whale_pos(0), whale_pos(1)) )
				on_land_ID = k ;

			// Very "raw" estimation from last nearest distance
			// Useful when there are big differences between distances to zones
			if ( d(k) < (d_min+Max_Speed) ) {
				y = distCoast(whale_pos, beach_x, beach_y) ;
				if ( on_land_ID < 0 )
					d(k) = min(y) ; 
				else // On land !!
					d(k) = 0 ; 
			}
			else { // If not, estimate a simple lower bound 
				d(k) -= Max_Speed ;
			}
		}
		
		if ( on_land_ID < 0 ) { // Not on land
			j = which_min(d);
			D(i) = min(d) ;
		}
		else { // On land
			j = on_land_ID ;
			D(i) = 0 ; 			
		}
		
		ID(i) = nearest_zone_ID(j) ;
		d_min = D(i) ;
	}
	
	return DataFrame::create( Named("DateTime") = path["DateTime"],
															 Named("Zone_ID")= ID,
															 Named("Distance")= D ) ;
}

// [How can I determine whether a 2D Point is within a Polygon?]
// https://stackoverflow.com/a/2922778
inline bool pnpoly(Rcpp::NumericVector& X, Rcpp::NumericVector& Y, 
											double Point_X, double Point_Y)
{
	int i, j;
	bool c = false;
	int nvert = X.size() ;
	
	for (i = 0, j = nvert-1; i < nvert; j = i++) {
		if ( ( (Y[i]>Point_Y) != (Y[j]>Point_Y) ) &&
			(Point_X < (X[j]-X[i]) * (Point_Y-Y[i]) / (Y[j]-Y[i]) + X[i]) )
			c = !c;
	}
	
	return c;
}
