/*
 * datafile.h -- header format for single-channel digitized data files
 * in "MT" format (see Appendix D of Burgess, W.C., Lightning-induced
 * coupling of the radiation belts to geomagnetically conjugate
 * ionospheric regions, Ph.D. thesis, Stanford University, Stanford,
 * California, 1993).
 *
 * The MT header format consists of a master 512-byte header followed
 * by an arbitrary number of supplemental 512-byte headers.  Typically
 * there are no supplemental 512-byte headers, only the one master header,
 * but software to read MT format should be able to skip over any
 * supplemental headers declared in the master header.  The supplemental
 * headers are application-dependent; they might simply contain text
 * to explain the data in greater detail.
 *
 * For portability and ease of inspection, the header is made up entirely
 * of ASCII bytes.  For ease of reading with scanf, all multi-character
 * strings must be null-terminated.  All numbers, including floating-point
 * numbers, must be written as null terminated strings.  Floating-point
 * numbers may include decimal points and e+xx or e-xx exponential
 * notation as necessary.
 *
 * Please stick to the basic 128-char ASCII character set in all
 * fields.  However, if you need a greek letter "mu" in the
 * "calunits" field, a lower-case letter "u" may be interpreted by some
 * readers as a "mu" provided it comes before certain key characters or
 * character strings (e.g. "uV" "uPa" "uA" etc.).  Recognition of the
 * "u" as a "mu" is up to the reader software and is not required.
 *
 * If the bytes reserved for a field are incompletely filled by
 * characters or digits, the rest of the field is to be filled
 * with nulls ('\0').
 *
 * There are some single-character fields.  These are not read as
 * strings, but rather as single characters, and thus do not have
 * null-termination.
 *
 * The "DATA\0\0\0\0" identifier in the beginning is a "magic string"
 * that identifies the file as MT format.  Reader software must always
 * verify that a data file begins with these eight characters.
*/

#ifndef _DATAFILE_H_
#define _DATAFILE_H_

/*
 * This is how many characters, INCLUDING null terminator,
 * calibration value strings can be.
*/
#define MAX_CALSTRING_CHARS 15

/*
 * Possible values for the typemark field.
*/
#define AMPLITUDE   'A'
#define PHASE       'P'
#define REFERENCE   'R'
#define SPECIAL     'S' /* special or unknown */
#define PEAKDETECT  'D' /* from peak detector */
#define DUMMY       ' ' /* invalid data! */
#define NOINFO      '\0'/* no information -- data possibly
                         * from some old version of software
                         * or from stripped-down software...*/
/*
 * Possible values for the swapping field.
*/
#define SWAPPED     'S'  /* Little-Endian (Intel) */
#define UNSWAPPED   'U'  /* Big-Endian (Motorola) */

/*
 * Possible values for the signing field.
*/
#define SIGNED      'S'  /* Data's highest-order bit is sign bit */
#define UNSIGNED    'U'  /* No sign bit in data */

/*
 * Possible values for the caltype field.
 *
 * If uncalibrated, all other calibration-related fields are to be
 * ignored and may contain garbage.
 *
 * If either max or min values are calibrated, then the corresponding
 * "calmin" or "calmax" field should hold a reasonable floating point number.
 *
 * If the calibration type is FLOATINGPOINT, then the data themselves
 * are in float or double format (as opposed to integer format), and the
 * calmin and calmax fields should give the minimum and maximum
 * values occurring in the file.  The wordsize parameter will
 * determine whether these are 4-byte floats or 8-byte doubles.
 * In the unlikely event that the file contains floating-point values
 * untied to any specific calibration, use UNCAL_FLOATINGPOINT.
*/
#define CALIBRATED          'C'
#define UNCALIBRATED        'U'
#define ONLYMINCALIBRATED   'N'
#define ONLYMAXCALIBRATED   'X'
#define FLOATINGPOINT       'F'
#define UNCAL_FLOATINGPOINT 'f'

#define DATAFILE_TITLECHARS 82  /* 81 chars plus null terminator */
#define DATAFILE_STATIONCHARS 3 /* 2 chars plus null terminator */

struct datafilehdr {
   char magicstring[8], /* identifier, should be "DATA\0\0\0\0" */
        totalhdrs[3],   /* total number of 512-byte headers 
                         * incl. this one. (null-terminated ASCII) */
        abbrev[8],      /* 7 char abbreviation for title if any */
        stationcode[DATAFILE_STATIONCHARS], /* 2 char station code (PA, SU, etc.) */
        title[DATAFILE_TITLECHARS],      /* where the recording was made/title */
        month[3],       /* numeric WITH ZERO PLACEHOLDER,
                         * e.g. 03 = march, 10 = october, etc. */
        day[3],         /* numeric with zero placeholder */
        year[5],        /* 4-digit year, eg 1987 */
        hours[3],       /* numeric with zero placeholder */
        minutes[3],     /* numeric with zero placeholder */
        seconds[3],     /* numeric with zero placeholder */
        msec[4],        /* milliseconds later than above time,
                         * again with zero placeholders */
        sampling_period[15],	/* floating point number in seconds */
        samplebits[3],  /* BITS per data sample (e.g., "12") --
                         * this establishes min/max values */
        wordsize[2],    /* bytes reserved per data sample("1","2"...) */
        typemark,       /* see data type #defines above */
        swapping,       /* see swapping type #defines */
        signing,        /* see signing type #defines */
        caltype,        /* see calibration type #defines */
        calmin[MAX_CALSTRING_CHARS],     /* floating point min value if calibrated */
        calmax[MAX_CALSTRING_CHARS],     /* floating point max value if calibrated */
        calunits[40],   /* null-terminated units string (eg "volts") */
        recordsize[6],  /* suggested bytes to get in single read, usually 512 */
        sourcevers[9],  /* source version of code that wrote data */
        sourcesn[16],	/* serial number of unit that wrote data */
        fill[(512-253)];/* round out header to 512 bytes total.
                         * This region should not be filled with
                         * anything but nulls, so that later
                         * versions of this header will be
                         * compatible.  Any text comments should
                         * be placed in additional headers. */
};

#endif /* _DATAFILE_H_ */
